# The extension module loads the adjacent libexiv2.dylib via @loader_path.
from . import exiv2api
