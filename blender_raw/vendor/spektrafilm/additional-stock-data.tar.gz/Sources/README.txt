Pinned source: https://github.com/noahhaasis/negs/tree/2f5b5703d807e9490801d9155ac30b2c19460551
B&W profile JSONs and source records are retained without modification.
The experimental preparation records retain all source conditions and limitations.
Manufacturer PDF/raster excerpts are not included in this distribution.
Running the upstream preparation/overlay scripts requires the complete pinned
checkout, its spectral LUT, and the source excerpts acquired under their own rights.
Lite's native rebuild only needs the supplied profile JSONs, not those excerpts.
The upstream preparation/profile data licence is CC BY-SA 4.0; manufacturer
source rights remain with the respective holders. See each source record.
